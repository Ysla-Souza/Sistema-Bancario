package com.accenture.academico.sistemabanco;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaBancoApplicationTests {

	@Test
	void contextLoads() {
	}

}
